# 线性回归的从零开始实现
:label:`sec_linear_scratch`

在了解线性回归的关键思想之后，我们可以开始通过代码来动手实现线性回归了。
在这一节中，(**我们将从零开始实现整个方法，
包括数据流水线、模型、损失函数和小批量随机梯度下降优化器**)。
虽然现代的深度学习框架几乎可以自动化地进行所有这些工作，但从零开始实现可以确保我们真正知道自己在做什么。
同时，了解更细致的工作原理将方便我们自定义模型、自定义层或自定义损失函数。
在这一节中，我们将只使用张量和自动求导。
在之后的章节中，我们会充分利用深度学习框架的优势，介绍更简洁的实现方式。



```python
%matplotlib inline
import random
# import torch
from d2lkewei import mindspore as d2l
```

## 生成数据集

为了简单起见，我们将[**根据带有噪声的线性模型构造一个人造数据集。**]
我们的任务是使用这个有限样本的数据集来恢复这个模型的参数。
我们将使用低维数据，这样可以很容易地将其可视化。
在下面的代码中，我们生成一个包含1000个样本的数据集，
每个样本包含从标准正态分布中采样的2个特征。
我们的合成数据集是一个矩阵$\mathbf{X}\in \mathbb{R}^{1000 \times 2}$。

(**我们使用线性模型参数$\mathbf{w} = [2, -3.4]^\top$、$b = 4.2$
和噪声项$\epsilon$生成数据集及其标签：

$$\mathbf{y}= \mathbf{X} \mathbf{w} + b + \mathbf\epsilon.$$
**)

$\epsilon$可以视为模型预测和标签时的潜在观测误差。
在这里我们认为标准假设成立，即$\epsilon$服从均值为0的正态分布。
为了简化问题，我们将标准差设为0.01。
下面的代码生成合成数据集。



```python
import mindspore
import mindspore.ops as ops
import numpy as np

def synthetic_data(w, b, num_examples):
    """生成y=Xw+b+噪声"""
    X = mindspore.Tensor(np.random.normal(0, 1, (num_examples, len(w))).astype(np.float32))
    y = mindspore.Tensor.matmul(X, w) + b
    y += mindspore.Tensor(np.random.normal(0, 0.01, y.shape).astype(np.float32))
    return X, y.reshape((-1, 1))

```


```python
true_w = mindspore.Tensor([2, -3.4])
true_b = 4.2
features, labels = synthetic_data(true_w, true_b, 1000)
```

注意，[**`features`中的每一行都包含一个二维数据样本，
`labels`中的每一行都包含一维标签值（一个标量）**]。



```python
print('features:', features[0],'\nlabel:', labels[0])
```

    features: [-0.4659421  -0.21897846] 
    label: [4.0192623]


通过生成第二个特征`features[:, 1]`和`labels`的散点图，
可以直观观察到两者之间的线性关系。



```python
d2l.set_figsize()
d2l.plt.scatter(features[:, 1].asnumpy(), labels.asnumpy(), 1);
```


    
![svg](output_8_0.svg)
    


## 读取数据集

回想一下，训练模型时要对数据集进行遍历，每次抽取一小批量样本，并使用它们来更新我们的模型。
由于这个过程是训练机器学习算法的基础，所以有必要定义一个函数，
该函数能打乱数据集中的样本并以小批量方式获取数据。

在下面的代码中，我们[**定义一个`data_iter`函数，
该函数接收批量大小、特征矩阵和标签向量作为输入，生成大小为`batch_size`的小批量**]。
每个小批量包含一组特征和标签。



```python
def data_iter(batch_size, features, labels):
    num_examples = len(features)
    indices = list(range(num_examples))
    # 这些样本是随机读取的，没有特定的顺序
    random.shuffle(indices)
    for i in range(0, num_examples, batch_size):
        batch_indices = mindspore.Tensor(
            indices[i: min(i + batch_size, num_examples)])
        yield features[batch_indices], labels[batch_indices]
```

通常，我们利用GPU并行运算的优势，处理合理大小的“小批量”。
每个样本都可以并行地进行模型计算，且每个样本损失函数的梯度也可以被并行计算。
GPU可以在处理几百个样本时，所花费的时间不比处理一个样本时多太多。

我们直观感受一下小批量运算：读取第一个小批量数据样本并打印。
每个批量的特征维度显示批量大小和输入特征数。
同样的，批量的标签形状与`batch_size`相等。



```python
batch_size = 10

for X, y in data_iter(batch_size, features, labels):
    print(X, '\n', y)
    break
```

    [[-0.0522934  -1.7260509 ]
     [-0.01287904 -0.46941   ]
     [-0.27599585  1.5983486 ]
     [-0.52340215  1.5412471 ]
     [ 0.5381178  -1.4826521 ]
     [ 1.8539798   0.6439666 ]
     [ 0.8153787  -0.9565958 ]
     [-1.1380805   2.0105548 ]
     [ 0.20266283  0.7603957 ]
     [-0.16371438 -0.13636926]] 
     [[ 9.965386 ]
     [ 5.7748766]
     [-1.7982349]
     [-2.0780356]
     [10.306476 ]
     [ 5.713978 ]
     [ 9.099676 ]
     [-4.9308577]
     [ 2.0086184]
     [ 4.3314624]]


当我们运行迭代时，我们会连续地获得不同的小批量，直至遍历完整个数据集。
上面实现的迭代对教学来说很好，但它的执行效率很低，可能会在实际问题上陷入麻烦。
例如，它要求我们将所有数据加载到内存中，并执行大量的随机内存访问。
在深度学习框架中实现的内置迭代器效率要高得多，
它可以处理存储在文件中的数据和数据流提供的数据。

## 初始化模型参数

[**在我们开始用小批量随机梯度下降优化我们的模型参数之前**]，
(**我们需要先有一些参数**)。
在下面的代码中，我们通过从均值为0、标准差为0.01的正态分布中采样随机数来初始化权重，
并将偏置初始化为0。



```python
np.random.normal(0,0.01,(2,1))
```




    array([[-0.00201819],
           [-0.00154781]])




```python
import mindspore as ms
```


```python
from mindspore.common.initializer import initializer, Normal
w = ms.Tensor(np.random.normal(0,0.01,(2,1)), mindspore.float32)
b = ms.Tensor(ops.zeros(1, dtype=mindspore.float32))
```


```python
w,b
```




    (Tensor(shape=[2, 1], dtype=Float32, value=
     [[-5.39034605e-04],
      [-2.11896617e-02]]),
     Tensor(shape=[1], dtype=Float32, value= [ 0.00000000e+00]))




```python
w.value()
```




    Tensor(shape=[2, 1], dtype=Float32, value=
    [[-5.39034605e-04],
     [-2.11896617e-02]])



在初始化参数之后，我们的任务是更新这些参数，直到这些参数足够拟合我们的数据。
每次更新都需要计算损失函数关于模型参数的梯度。
有了这个梯度，我们就可以向减小损失的方向更新每个参数。
因为手动计算梯度很枯燥而且容易出错，所以没有人会手动计算梯度。
我们使用 :numref:`sec_autograd`中引入的自动微分来计算梯度。

## 定义模型

接下来，我们必须[**定义模型，将模型的输入和参数同模型的输出关联起来。**]
回想一下，要计算线性模型的输出，
我们只需计算输入特征$\mathbf{X}$和模型权重$\mathbf{w}$的矩阵-向量乘法后加上偏置$b$。
注意，上面的$\mathbf{Xw}$是一个向量，而$b$是一个标量。
回想一下 :numref:`subsec_broadcasting`中描述的广播机制：
当我们用一个向量加一个标量时，标量会被加到向量的每个分量上。



```python
def linreg(X, w, b):  #@save
    """线性回归模型"""
    return ops.matmul(X, w) + b
```


```python
from mindspore import grad
```


```python
def linreg(X, w, b):
    """线性回归模型"""
    return ops.matmul(X, w) + b
func = linreg
grad_fn = ms.grad(func, grad_position=1)
grad_w = grad_fn(X,w,b)
```


```python
def linreg(X, w, b):
    """线性回归模型"""
    return ops.matmul(X, w) + b
func = linreg
grad_fn = ms.grad(func, grad_position=(1,2))
grads = grad_fn(X,w,b)
```


```python
grads
```




    (Tensor(shape=[2, 1], dtype=Float32, value=
     [[ 1.24377406e+00],
      [ 1.78343499e+00]]),
     Tensor(shape=[1], dtype=Float32, value= [ 1.00000000e+01]))




```python
grad_w
```




    Tensor(shape=[2, 1], dtype=Float32, value=
    [[ 1.24377406e+00],
     [ 1.78343499e+00]])



## [**定义损失函数**]

因为需要计算损失函数的梯度，所以我们应该先定义损失函数。
这里我们使用 :numref:`sec_linear_regression`中描述的平方损失函数。
在实现中，我们需要将真实值`y`的形状转换为和预测值`y_hat`的形状相同。



```python
def squared_loss(y_hat, y):  #@save
    """均方损失"""
    return (y_hat - y.reshape(y_hat.shape)) ** 2 / 2
```

## (**定义优化算法**)

正如我们在 :numref:`sec_linear_regression`中讨论的，线性回归有解析解。
尽管线性回归有解析解，但本书中的其他模型却没有。
这里我们介绍小批量随机梯度下降。

在每一步中，使用从数据集中随机抽取的一个小批量，然后根据参数计算损失的梯度。
接下来，朝着减少损失的方向更新我们的参数。
下面的函数实现小批量随机梯度下降更新。
该函数接受模型参数集合、学习速率和批量大小作为输入。每
一步更新的大小由学习速率`lr`决定。
因为我们计算的损失是一个批量样本的总和，所以我们用批量大小（`batch_size`）
来规范化步长，这样步长大小就不会取决于我们对批量大小的选择。



```python
def sgd(params, params_grad, lr, batch_size):  #@save
    """小批量随机梯度下降"""
    assert len(params) == len(params_grad)
    for i in range(len(params)):
        params[i] -= lr * params_grad[i] / batch_size
    return params
```

`with torch.no_grad()`是一个上下文管理器，用于指定在该上下文中不需要计算梯度。具体来说，当我们使用`torch.no_grad()`包装一段代码时，PyTorch将禁用自动微分引擎，从而节省内存并提高代码的执行速度。这在评估模型时非常有用，因为我们通常不需要计算梯度。此外，在某些情况下，例如在使用预训练模型进行推理时，禁用自动微分引擎可以防止意外修改模型参数。

## 训练

现在我们已经准备好了模型训练所有需要的要素，可以实现主要的[**训练过程**]部分了。
理解这段代码至关重要，因为从事深度学习后，
相同的训练过程几乎一遍又一遍地出现。
在每次迭代中，我们读取一小批量训练样本，并通过我们的模型来获得一组预测。
计算完损失后，我们开始反向传播，存储每个参数的梯度。
最后，我们调用优化算法`sgd`来更新模型参数。

概括一下，我们将执行以下循环：

* 初始化参数
* 重复以下训练，直到完成
    * 计算梯度$\mathbf{g} \leftarrow \partial_{(\mathbf{w},b)} \frac{1}{|\mathcal{B}|} \sum_{i \in \mathcal{B}} l(\mathbf{x}^{(i)}, y^{(i)}, \mathbf{w}, b)$
    * 更新参数$(\mathbf{w}, b) \leftarrow (\mathbf{w}, b) - \eta \mathbf{g}$

在每个*迭代周期*（epoch）中，我们使用`data_iter`函数遍历整个数据集，
并将训练数据集中所有样本都使用一次（假设样本数能够被批量大小整除）。
这里的迭代周期个数`num_epochs`和学习率`lr`都是超参数，分别设为3和0.03。
设置超参数很棘手，需要通过反复试验进行调整。
我们现在忽略这些细节，以后会在 :numref:`chap_optimization`中详细介绍。



```python
lr = 0.03
num_epochs = 3
net = linreg
loss = squared_loss
```


```python
for epoch in range(num_epochs):
    for X, y in data_iter(batch_size, features, labels):
        def subf(X,w,b):
            l = loss(net(X, w, b), y)  # X和y的小批量损失
            l = l.sum()
            # 因为l形状是(batch_size,1)，而不是一个标量。l中的所有元素被加到一起，
            # 并以此计算关于[w,b]的梯度
            return l
        grad_fn = ms.grad(subf, grad_position=(1,2))
        grads = grad_fn(X,w,b)
        # l.sum().backward() #会把梯度求和，对应sgd函数中的除以batch_size求平均值
        [w,b] = sgd([w, b], grads, lr, batch_size)  # 使用参数的梯度更新参数
        # print(w1==w)
        # print(w,b)
    train_l = loss(net(features, w, b), labels)
    print(f'epoch {epoch + 1}, loss {float(train_l.mean()):f}')
```

    epoch 1, loss 0.038414
    epoch 2, loss 0.000138
    epoch 3, loss 0.000050


因为我们使用的是自己合成的数据集，所以我们知道真正的参数是什么。
因此，我们可以通过[**比较真实参数和通过训练学到的参数来评估训练的成功程度**]。
事实上，真实参数和通过训练学到的参数确实非常接近。



```python
print(f'w的估计误差: {true_w - w.reshape(true_w.shape)}')
print(f'b的估计误差: {true_b - b}')
```

    w的估计误差: [ 9.381771e-05 -3.991127e-04]
    b的估计误差: [0.00103045]



```python
w,b
```




    (Tensor(shape=[2, 1], dtype=Float32, value=
     [[ 1.99990618e+00],
      [-3.39960098e+00]]),
     Tensor(shape=[1], dtype=Float32, value= [ 4.19896936e+00]))



注意，我们不应该想当然地认为我们能够完美地求解参数。
在机器学习中，我们通常不太关心恢复真正的参数，而更关心如何高度准确预测参数。
幸运的是，即使是在复杂的优化问题上，随机梯度下降通常也能找到非常好的解。
其中一个原因是，在深度网络中存在许多参数组合能够实现高度精确的预测。

## 小结

* 我们学习了深度网络是如何实现和优化的。在这一过程中只使用张量和自动微分，不需要定义层或复杂的优化器。
* 这一节只触及到了表面知识。在下面的部分中，我们将基于刚刚介绍的概念描述其他模型，并学习如何更简洁地实现其他模型。

## 练习

1. 如果我们将权重初始化为零，会发生什么。算法仍然有效吗？
1. 假设试图为电压和电流的关系建立一个模型。自动微分可以用来学习模型的参数吗?
1. 能基于[普朗克定律](https://en.wikipedia.org/wiki/Planck%27s_law)使用光谱能量密度来确定物体的温度吗？
1. 计算二阶导数时可能会遇到什么问题？这些问题可以如何解决？
1. 为什么在`squared_loss`函数中需要使用`reshape`函数？
1. 尝试使用不同的学习率，观察损失函数值下降的快慢。
1. 如果样本个数不能被批量大小整除，`data_iter`函数的行为会有什么变化？


## 第1题

1. 如果我们将权重初始化为零，会发生什么。算法仍然有效吗？

1. 如果将权重初始化为零，那么每个神经元的输出都是相同的，这意味着每个神经元学习到的参数也是相同的。因此，每个神经元都会更新相同的参数，最终导致所有神经元学习到相同的特征。因此，权重初始化为零会使算法失效。

注意，把w,b全部初始化为0是不会影响的

权重初始化为零会使算法失效的说法是正确的。如果将权重初始化为零，那么每个神经元的输出都是相同的，这意味着每个神经元学习到的参数也是相同的。因此，每个神经元都会更新相同的参数，最终导致所有神经元学习到相同的特征。这样就失去了神经网络的优势，即可以学习到不同特征的能力。

您在使用全零初始化时得到了最终结果，可能是因为您使用了其他技巧来避免这种情况发生。例如，在训练过程中使用了正则化或者dropout等技术，这些技术可以帮助避免所有神经元学习到相同的特征。

逻辑回归可以存在权重初始化为0.
https://zhuanlan.zhihu.com/p/75879624

根据网络搜索结果，逻辑回归和神经网络有不同的权重初始化方法。对于逻辑回归，可以将权重初始化为零，因为这是一个线性模型，梯度下降算法仍然可以更新它们。然而，对于神经网络来说，将权重初始化为零可能会导致对称性问题，并阻止隐藏单元学习不同的特征。因此，最好使用随机或其他方法来初始化神经网络的权重。

## 第2题

假设试图为电压和电流的关系建立一个模型。自动微分可以用来学习模型的参数吗?

自动微分（Automatic Differentiation，简称AD）是一种对计算机程序进行高效准确求导的技术。它是介于符号微分和数值微分之间的一种方法，可以计算可导函数在某点处的导数值的计算，是反向传播算法的一般化。

自动微分要解决的核心问题是计算复杂函数，通常是多层复合函数在某一点处的导数、梯度以及Hessian矩阵值
torch中的backward就是自动微分。backward()函数会自动计算所有需要求导的变量的梯度，并将结果存储在相应变量的grad属性中。




```python
from tqdm import tqdm
```


```python
import mindspore as ms

# 生成数据
x = ms.ops.randn(100, 1)
y = 3 * x + 0.5 * ms.ops.randn(100, 1)

# 定义模型
model = ms.nn.Dense(1, 1)

# 定义损失函数和优化器
criterion = ms.nn.MSELoss()
optimizer = ms.nn.SGD(model.trainable_params(), learning_rate=0.01)
def forward_fn(x, y):
    y_hat = model(x)
    l = criterion(y_hat, y).mean()
    return l

# 训练模型
for epoch in tqdm(range(1000)):

    grad_fn = ms.value_and_grad(forward_fn, grad_position=None, weights=optimizer.parameters)
    l, grads = grad_fn(x, y)
    y_pred = model(x)
    optimizer(grads)


print(model.weight)
print(model.bias)
```

    100%|█████████████████████████████████████████████████████████████████████| 1000/1000 [00:25<00:00, 39.65it/s]

    Parameter (name=weight, shape=(1, 1), dtype=Float32, requires_grad=True)
    Parameter (name=bias, shape=(1,), dtype=Float32, requires_grad=True)


    



```python
model.weight.value()
```




    Tensor(shape=[1, 1], dtype=Float32, value=
    [[ 3.01565051e+00]])




```python
model.bias.value()
```




    Tensor(shape=[1], dtype=Float32, value= [ 5.50353564e-02])



## 第3题

能基于[普朗克定律](https://en.wikipedia.org/wiki/Planck%27s_law)使用光谱能量密度来确定物体的温度吗？

3. 是的，可以使用普朗克定律来确定物体的温度。普朗克定律描述了黑体辐射的能量密度与温度之间的关系。通过测量物体发出的辐射能量密度，并使用普朗克定律，我们可以确定物体的温度。

## 第4题

计算二阶导数时可能会遇到什么问题？这些问题可以如何解决？

4. 在计算二阶导数时可能会遇到数值不稳定性问题。这些问题可以通过使用更高精度的数据类型（例如双精度浮点数）或通过使用数值稳定性技巧（例如中心差分）来解决。

数值不稳定性是指在数值计算过程中，由于舍入误差、截断误差等原因，导致计算结果的精度出现大幅度波动或者发散。例如，在计算二阶导数时，如果使用简单的有限差分公式，可能会出现数值不稳定性问题。这些问题可以通过使用更高精度的数据类型（例如双精度浮点数）或通过使用数值稳定性技巧（例如中心差分）来解决。

中心差分是一种常用的数值稳定性技巧，它可以用于计算函数在某个点处的导数。具体来说，中心差分可以通过以下公式计算：

$$f'(x) \approx \frac{f(x+h)-f(x-h)}{2h}$$

其中 $h$ 是一个很小的正数，通常取 $10^{-6}$ 或更小。

## 第5题


```python
1. 为什么在`squared_loss`函数中需要使用`reshape`函数？

```


```python
reshape
```

## 第6题


```python
1. 尝试使用不同的学习率，观察损失函数值下降的快慢。

```


```python
lr=[0.1,0.001,0.001,0.05,..]
for lr:
    model.train
```

## 第7题


```python
1. 如果样本个数不能被批量大小整除，`data_iter`函数的行为会有什么变化？
```

如果样本个数不能被批量大小整除，则在最后一个迭代周期中，最后一批次可能包含少于批量大小个样本。在这种情况下，我们只需忽略该批次中多余的样本即可。

例如，1000个总样本，batch_size=3,那么最后1个样本会被舍去



2. 可以使用自动微分来学习模型参数。自动微分是一种计算梯度的技术，它可以自动地计算函数的导数。在深度学习中，我们通常使用反向传播算法来计算模型参数的梯度。





5. 在`squared_loss`函数中需要使用`reshape`函数是因为输入数据可能具有多个维度。在这种情况下，我们需要将输入数据转换为一个二维张量，其中每行对应于一个样本，并且每列对应于一个特征。通过调用`reshape`函数并指定新形状为`(batch_size, num_outputs)`，我们可以将输入数据转换为正确的形状以进行矩阵运算。

6. 学习率控制了模型参数更新时所采取的步长大小。如果学习率过大，则模型可能会发散并无法收敛；如果学习率过小，则模型可能需要更长时间才能收敛到最优解。因此，在实践中，我们通常需要尝试不同的学习率，并选择表现最好的那个。

7. 如果样本个数不能被批量大小整除，则在最后一个迭代周期中，最后一批次可能包含少于批量大小个样本。在这种情况下，我们只需忽略该批次中多余的样本即可。

二阶导数的数值不稳定性问题是指在数值计算时，由于舍入误差、截断误差等原因，导致计算结果的精度下降，进而影响计算结果的正确性。在数值计算中，为了提高计算精度，常常采用高阶差分公式来近似求解导数。但是，高阶差分公式的截断误差较大，在计算过程中容易受到舍入误差的影响，从而导致计算结果不稳定。¹²


二阶导数_百度百科. https://baike.baidu.com/item/二阶导数/1139067 访问时间 2023/3/22.
(2) 偏微分方程数值解不稳定性的本质 - 知乎. https://zhuanlan.zhihu.com/p/270786539 访问时间 2023/3/22.
(3) 有限差分法（1）—构造差分格式及稳定性分析 - 知乎. https://zhuanlan.zhihu.com/p/136269281 访问时间 2023/3/22.

为了避免二阶导数的数值不稳定性问题，可以采用以下方法：¹

- 采用更高精度的计算方法，如使用更高阶的差分公式；
- 采用更小的步长，以减小舍入误差；
- 采用更加稳定的数值方法，如龙格-库塔法等。

(1) 偏微分方程数值解不稳定性的本质 - 知乎. https://zhuanlan.zhihu.com/p/270786539 访问时间 2023/3/22.

(2) 二阶导数_百度百科. https://baike.baidu.com/item/二阶导数/1139067 访问时间 2023/3/22.

(3) 使用 COMSOL 理解稳定性方法 - 知乎. https://zhuanlan.zhihu.com/p/419013302 访问时间 2023/3/22.


```python

```

[Discussions](https://discuss.d2l.ai/t/1778)

